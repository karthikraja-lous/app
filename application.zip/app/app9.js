const quizData = [
    {
      question: "The number of electrons that have a total charge of 9650 coulombs is",
      a: "6.22 × 10²³",
      b: "6.022 × 10²⁴",
      c: "6.022 × 10²²",
      d: "6.022 × 10⁻³⁴",
      correct: "",
    },
    {
      question: "Consider the following half cell reactions:<br>Mn²⁺ + 2e⁻ → Mn E⁰ = -1.18V<br>Mn²⁺ → Mn³⁺ + e⁻ E⁰ = -1.51V<br>The E⁰ for the reaction 3Mn²⁺ → Mn + 2Mn³⁺, and the possibility of the forward reaction are respectively.",
      a: "2.69V and spontaneous",
      b: "-2.69V and non spontaneous",
      c: "0.33V and Spontaneous",
      d: "4.18V and non spontaneous",
      correct: "",
    },
    {
      question: "The button cell used in watches function as follows<br>Zn (s) + Ag₂O (s) + H₂O (l) ↔ 2 Ag (s) + Zn²⁺ (aq) + 2OH⁻ (aq)<br>The cell potentials are<br>Ag₂O (s) + H₂O (l) + 2e⁻ → 2Ag (s) + 2OH⁻ (aq) E⁰ = 0.34V<br>Zn (s) → Zn²⁺ (aq) + 2e⁻ E⁰ = 0.76 V. The cell potential will be",
      a: "0.84V",
      b: "1.34V",
      c: "1.10V",
      d: "0.42V",
      correct: "",
    },
    {
      question: "The molar conductivity of a 0.5 mol dm⁻³ solution of AgNO₃ with electrolytic conductivity of 5.76 × 10⁻³ S cm⁻¹ at 298 K is",
      a: "2.88 S cm² mol⁻¹",
      b: "11.52 S cm² mol⁻¹",
      c: "0.086 S cm² mol⁻¹",
      d: "28.8 S cm² mol⁻¹",
      correct: "",
    },
    {
      question: "Calculate Λ⁰<sub>HOAC</sub> using appropriate molar conductances of the electrolytes listed above at infinite dilution in water at 25°C:<br>Electrolyte: KCl, Λ⁰: 149.9<br>KNO₃, Λ⁰: 145.0<br>HCl, Λ⁰: 426.2<br>NaOAC, Λ⁰: 91.0<br>NaCl, Λ⁰: 126.5",
      a: "517.2",
      b: "552.7",
      c: "390.7",
      d: "217.5",
      correct: "",
    },
    {
      question: "Faraday constant is defined as",
      a: "charge carried by 1 electron",
      b: "charge carried by one mole of electrons",
      c: "charge required to deposit one mole of substance",
      d: "charge carried by 6.22 × 10¹⁰ electrons",
      correct: "",
    },
    {
      question: "How many faradays of electricity are required for the following reaction to occur:<br>MnO₄⁻ → Mn²⁺",
      a: "5F",
      b: "3F",
      c: "1F",
      d: "7F",
      correct: "",
    },
    {
      question: "A current strength of 3.86 A was passed through molten Calcium oxide for 41 minutes and 40 seconds. The mass of Calcium in grams deposited at the cathode is (atomic mass of Ca is 40g/mol and 1F = 96500C).",
      a: "4",
      b: "2",
      c: "8",
      d: "6",
      correct: "",
    },
    {
      question: "During electrolysis of molten sodium chloride, the time required to produce 0.1 mole of chlorine gas using a current of 3A is",
      a: "55 minutes",
      b: "107.2 minutes",
      c: "220 minutes",
      d: "330 minutes",
      correct: "",
    },
    {
      question: "The number of electrons delivered at the cathode during electrolysis by a current of 1A in 60 seconds is (charge of electron = 1.6 × 10⁻¹⁹ C)",
      a: "6.22 × 10²³",
      b: "6.022 × 10²⁰",
      c: "3.75 × 10²⁰",
      d: "7.48 × 10²³",
      correct: "",
    },
    {
      question: "Which of the following electrolytic solution has the least specific conductance",
      a: "2N",
      b: "0.002N",
      c: "0.02N",
      d: "0.2N",
      correct: "",
    },
    {
      question: "While charging lead storage battery",
      a: "PbSO₄ on cathode is reduced to Pb",
      b: "PbSO₄ on anode is oxidised to PbO₂",
      c: "PbSO₄ on anode is reduced to Pb",
      d: "PbSO₄ on cathode is oxidised to Pb",
      correct: "",
    },
    {
      question: "Among the following cells:<br>I) Leclanche cell<br>II) Nickel – Cadmium cell<br>III) Lead storage battery<br>IV) Mercury cell<br>Primary cells are",
      a: "I and IV",
      b: "I and III",
      c: "III and IV",
      d: "II and III",
      correct: "",
    },
    {
      question: "Zinc can be coated on iron to produce galvanized iron but the reverse is not possible. It is because",
      a: "Zinc is lighter than iron",
      b: "Zinc has lower melting point than iron",
      c: "Zinc has lower negative electrode potential than iron",
      d: "Zinc has higher negative electrode potential than iron",
      correct: "",
    },
    {
      question: "Assertion: pure iron when heated in dry air is converted with a layer of rust.<br>Reason: Rust has the composition Fe₃O₄",
      a: "If both assertion and reason are true and reason is the correct explanation of assertion.",
      b: "If both assertion and reason are true but reason is not the correct explanation of assertion.",
      c: "Assertion is true but reason is false.",
      d: "Both assertion and reason are false.",
      correct: "",
    },
    {
      question: "In H₂-O₂ fuel cell the reaction occurs at cathode is",
      a: "O₂ (g) + 2H₂O (l) + 4e⁻ → 4OH⁻ (aq)",
      b: "H⁺ (aq) + OH⁻ (aq) → H₂O (l)",
      c: "2H₂ (g) + O₂ (g) → 2H₂O (g)",
      d: "H⁺ + e⁻ → 1/2 H₂",
      correct: "",
    },
    {
      question: "The equivalent conductance of 0.01M solution of a weak monobasic acid is 6 mho cm² equivalent⁻¹ and at infinite dilution is 400 mho cm² equivalent⁻¹. The dissociation constant of this acid is",
      a: "1.25 × 10⁻⁶",
      b: "6.25 × 10⁻⁶",
      c: "1.25 × 10⁻⁴",
      d: "6.25 × 10⁻⁵",
      correct: "",
    },
    {
      question: "A conductivity cell has been calibrated with a 0.01M, 1:1 electrolytic solution (specific conductance κ = 1.25 × 10⁻³ S cm⁻¹) in the cell and the measured resistance was 800 Ω at 25°C. The cell constant is",
      a: "10⁻¹ cm⁻¹",
      b: "10¹ cm⁻¹",
      c: "1 cm⁻¹",
      d: "5.7 × 10⁻¹² cm⁻¹",
      correct: "",
    },
    {
      question: "Conductivity of a saturated solution of a sparingly soluble salt AB (1:1 electrolyte) at 298K is 1.85 × 10⁻⁵ S m⁻¹. Solubility product of the salt AB at 298K (Λ⁰<sub>m</sub>) AB = 14 × 10⁻³ S m² mol⁻¹.",
      a: "5.7 × 10⁻¹²",
      b: "1.32 × 10⁻¹²",
      c: "7.5 × 10⁻¹²",
      d: "1.74 × 10⁻¹²",
      correct: "",
    },
    {
      question: "In the electrochemical cell: Zn | ZnSO₄ (0.01M) || CuSO₄ (1.0M) | Cu, the emf of this Daniel cell is E₁. When the concentration of ZnSO₄ is changed to 1.0M and that of CuSO₄ changed to 0.01M, the emf changes to E₂. From the above, which one is the relationship between E₁ and E₂?",
      a: "E₁ < E₂",
      b: "E₁ > E₂",
      c: "E₂ ≥ E₁",
      d: "E₁ = E₂",
      correct: "",
    },
    {
      question: "Consider the change in oxidation state of Bromine corresponding to different emf values as shown in the diagram below:<br>BrO₄⁻ → BrO₃⁻, E⁰ = 1.82V<br>BrO₃⁻ → HBrO, E⁰ = 1.5V<br>HBrO → Br₂, E⁰ = 1.595V<br>Br₂ → Br⁻, E⁰ = 1.0652V<br>Then the species undergoing disproportionation is",
      a: "Br₂",
      b: "BrO₄⁻",
      c: "BrO₃⁻",
      d: "HBrO",
      correct: "",
    },
    {
      question: "For the cell reaction:<br>2Fe³⁺ (aq) + 2I⁻(aq) → 2Fe²⁺ (aq) + I₂ (aq)<br>E⁰<sub>cell</sub> = 0.24V at 298K. The standard Gibbs energy (∆G⁰) of the cell reactions is:",
      a: "-46.32 KJ mol⁻¹",
      b: "-23.16 KJ mol⁻¹",
      c: "46.32 KJ mol⁻¹",
      d: "23.16 KJ mol⁻¹",
      correct: "",
    },
    {
      question: "A certain current liberated 0.504gm of hydrogen in 2 hours. How many grams of copper can be liberated by the same current flowing for the same time through copper sulphate solution",
      a: "31.75",
      b: "15.8",
      c: "7.5",
      d: "63.5",
      correct: "",
    },
    {
      question: "A gas X at 1 atm is bubbled through a solution containing a mixture of 1M Y⁻ and 1M Z⁻ at 25°C. If the reduction potential of Z > Y > X, then",
      a: "Y will oxidize X and not Z",
      b: "Y will oxidize Z and not X",
      c: "Y will oxidize both X and Z",
      d: "Y will reduce both X and Z",
      correct: "",
    },
    {
      question: "Cell equation: A²⁺ + 2B⁻ → A + 2B<br>A²⁺ + 2e⁻ → A E⁰ = +0.34V and log<sub>10</sub>K = 15.6 at 300K for cell reactions. Find E⁰ for B⁺ + e⁻ → B",
      a: "0.80",
      b: "1.26",
      c: "-0.54",
      d: "-10.94",
      correct: "",
    },
  ];
  
  let index = 0;
  let correct = 0,
      incorrect = 0,
      total = quizData.length;
  let questionBox = document.getElementById("questionBox");
  let allInputs = document.querySelectorAll("input[type='radio']");
  
  const submitButton = document.querySelector("#submit");
  submitButton.disabled = true; // Initially disable the submit button
  
  // Add event listener to each input to enable/disable submit button
  allInputs.forEach(input => {
    input.addEventListener('change', () => {
      submitButton.disabled = !document.querySelector('input[type="radio"]:checked'); // Enable submit button if any radio button is checked
    });
  });
  
  // Add event listener to submit button
  submitButton.addEventListener('click', () => {
    const ans = getAnswer();
    if (ans) {
      const data = quizData[index];
      if (ans === data.correct) {
        correct++;
      } else {
        incorrect++;
      }
      index++;
      if (index < total) {
        loadQuestion();
      } else {
        quizEnd();
      }
      submitButton.disabled = true; // Disable submit button after submission
    }
  });
  
  const loadQuestion = () => {
    if (total === index) {
      return quizEnd();
    }
    reset();
    const data = quizData[index];
    questionBox.innerHTML = `${index + 1}) ${data.question}`;
    allInputs[0].nextElementSibling.innerText = data.a;
    allInputs[1].nextElementSibling.innerText = data.b;
    allInputs[2].nextElementSibling.innerText = data.c;
    allInputs[3].nextElementSibling.innerText = data.d;
  };
  
  const getAnswer = () => {
    let ans;
    allInputs.forEach(
      (inputEl) => {
        if (inputEl.checked) {
          ans = inputEl.value;
        }
      }
    )
    return ans;
  }
  
  const reset = () => {
    allInputs.forEach(
      (inputEl) => {
        inputEl.checked = false;
      }
    )
  }
  
  const quizEnd = () => {
    document.getElementsByClassName("container")[0].innerHTML = `
      <div class="col">
          <h2> Total correct ${correct} from ${total} </h2>
          <a align="center" href="./">Home</a>
      </div>
    `
  }
  
  loadQuestion(index);
  