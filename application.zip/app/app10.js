const quizData = [
    {
      question: "c10o1.png",
      a: "log 1 , k",
      b: "1 , log k",
      c: "1 , k",
      d: "log 1 , log k",
      correct: "",
    },
    {
      question: "Which of the following is incorrect for physisorption?",
      a: "reversible",
      b: "increases with increase in temperature",
      c: "low heat of adsorption",
      d: "increases with increase in surface area",
      correct: "",
    },
    {
      question: "Which one of the following characteristics are associated with adsorption? (NEET)",
      a: "ΔG and ΔH are negative but ΔS is positive",
      b: "ΔG and ΔS are negative but ΔH is positive",
      c: "ΔG is negative but ΔH and ΔS are positive",
      d: "ΔG, ΔH and ΔS all are negative",
      correct: "",
    },
    {
      question: "Fog is colloidal solution of",
      a: "solid in gas",
      b: "gas in gas",
      c: "liquid in gas",
      d: "gas in liquid",
      correct: "",
    },
    {
      question: "Assertion: Coagulation power of Al³⁺ is more than Na⁺. Reason: greater the valency of the flocculating ion added, greater is its power to cause precipitation",
      a: "if both assertion and reason are true and reason is the correct explanation of assertion.",
      b: "if both assertion and reason are true but reason is not the correct explanation of assertion.",
      c: "assertion is true but reason is false",
      d: "both assertion and reason are false",
      correct: "",
    },
    {
      question: "To stop bleeding from an injury, ferric chloride can be applied. Which comment about the statement is justified?",
      a: "It is not true, ferric chloride is a poison.",
      b: "It is true, Fe³⁺ ions coagulate blood which is a negatively charged sol",
      c: "It is not true; ferric chloride is ionic and gets into the blood stream.",
      d: "It is true, coagulation takes place because of formation of negatively charged sol with Cl⁻.",
      correct: "",
    },
    {
      question: "Hair cream is",
      a: "gel",
      b: "emulsion",
      c: "solid sol",
      d: "sol",
      correct: "",
    },
    {
      question: "Which one of the following is correctly matched?",
      a: "Emulsion – Smoke",
      b: "Gel – butter",
      c: "foam – Mist",
      d: "whipped cream – sol",
      correct: "",
    },
    {
      question: "The most effective electrolyte for the coagulation of As₂S₃ sol is",
      a: "NaCl",
      b: "Ba(NO₃)₂",
      c: "K₃[Fe(CN)₆]",
      d: "Al₂(SO₄)₃",
      correct: "",
    },
    {
      question: "Which one of the is not a surfactant?",
      a: "CH₃(CH₂)₁₅N⁺(CH₃)₂Br⁻",
      b: "CH₃(CH₂)₁₅NH₂",
      c: "CH₃(CH₂)₁₆CH₂OSO₂Na⁺",
      d: "OHC(CH₂)₁₄CH₂COONa⁺",
      correct: "",
    },
    {
      question: "The phenomenon observed when a beam of light is passed through a colloidal solution is",
      a: "Cataphoresis",
      b: "Electrophoresis",
      c: "Coagulation",
      d: "Tyndall effect",
      correct: "",
    },
    {
      question: "In an electrical field, the particles of a colloidal system move towards cathode. The coagulation of the same sol is studied using K₂SO₄ (i), Na₃PO₄ (ii), K₄[Fe(CN)₆] (iii) and NaCl (iv). Their coagulating power should be",
      a: "II > I > IV > III",
      b: "III > II > I > IV",
      c: "I > II > III > IV",
      d: "none of these",
      correct: "",
    },
    {
      question: "Collodion is a 4% solution of which one of the following compounds in alcohol – ether mixture?",
      a: "Nitroglycerine",
      b: "Cellulose acetate",
      c: "Glycoldinitrate",
      d: "Nitrocellulose",
      correct: "",
    },
    {
      question: "Which one of the following is an example for homogeneous catalysis?",
      a: "manufacture of ammonia by Haber’s process",
      b: "manufacture of sulphuric acid by contact process",
      c: "hydrogenation of oil",
      d: "Hydrolysis of sucrose in presence of dil HCl",
      correct: "",
    },
    {
      question: "Match the following",
      a: "V₂O₅ - (iv) H₂SO₄",
      b: "Ziegler – Natta - (i) High density polyethylene",
      c: "Peroxide - (ii) PAN",
      d: "Finely divided Fe - (iii) NH₃",
      correct: "",
    },
    {
      question: "The coagulation values in millimoles per litre of the electrolytes used for the coagulation of As₂S₃ are given below (I) (NaCl)=52 (II) (BaCl₂)=0.69 (III) (MgSO₄)=0.22. The correct order of their coagulating power is",
      a: "III > II > I",
      b: "I > II > III",
      c: "I > III > II",
      d: "II > III > I",
      correct: "",
    },
    {
      question: "Adsorption of a gas on solid metal surface is spontaneous and exothermic, then",
      a: "ΔH increases",
      b: "ΔS increases",
      c: "ΔG increases",
      d: "ΔS decreases",
      correct: "",
    },
    {
      question: "If x is the amount of adsorbate and m is the amount of adsorbent, which of the following relations is not related to adsorption process?",
      a: "x = f(P) at constant T",
      b: "x = f(T) at constant P",
      c: "P = f(T) at constant x",
      d: "x = P*T",
      correct: "",
    },
    {
      question: "On which of the following properties does the coagulating power of an ion depend? (NEET – 2018)",
      a: "Both magnitude and sign of the charge on the ion",
      b: "Size of the ion alone",
      c: "the magnitude of the charge on the ion alone",
      d: "the sign of charge on the ion alone",
      correct: "",
    },
    {
      question: "Match the following",
      a: "Pure nitrogen - (iv) sodium azide (or) Barium azide",
      b: "Haber process - (iii) Ammonia",
      c: "Contact process - (ii) Sulphuric acid",
      d: "Deacon's Process - (i) Chlorine",
      correct: "",
    },
  ];
  
  
  let index = 0;
  let correct = 0,
  incorrect = 0,
  total = quizData.length;
  let questionBox = document.getElementById("questionBox");
  let allInputs = document.querySelectorAll("input[type='radio']");
  
  const submitButton = document.querySelector("#submit");
  submitButton.disabled = true; // Initially disable the submit button
  
  // Add event listener to each input to enable/disable submit button
  allInputs.forEach(input => {
  input.addEventListener('change', () => {
    submitButton.disabled = !document.querySelector('input[type="radio"]:checked'); // Enable submit button if any radio button is checked
  });
  });
  
  // Add event listener to submit button
  submitButton.addEventListener('click', () => {
  const ans = getAnswer();
  if (ans) {
    const data = quizData[index];
    if (ans === data.correct) {
        correct++;
    } else {
        incorrect++;
    }
    index++;
    if (index < total) {
        loadQuestion();
    } else {
        quizEnd();
    }
    submitButton.disabled = true; // Disable submit button after submission
  }
  });
  
  const loadQuestion = () => {
  if (total === index) {
    return quizEnd();
  }
  reset();
  const data = quizData[index];
  if (data.question.includes('.jpg') || data.question.includes('.png') || data.question.includes('.jpeg')) {
    questionBox.innerHTML = `
        <div>
            <img src="${data.question}" alt="Question Image" />
        </div>
    `;
  } else {
    questionBox.innerHTML = `${index + 1}) ${data.question}`;
  }
  
  // Handling options
  if (data.a.includes('.jpg') || data.a.includes('.png') || data.a.includes('.jpeg')) {
    allInputs[0].nextElementSibling.innerHTML = `<img src="${data.a}" alt="Option A" />`;
  } else {
    allInputs[0].nextElementSibling.innerText = data.a;
  }
  
  if (data.b.includes('.jpg') || data.b.includes('.png') || data.b.includes('.jpeg')) {
    allInputs[1].nextElementSibling.innerHTML = `<img src="${data.b}" alt="Option B" />`;
  } else {
    allInputs[1].nextElementSibling.innerText = data.b;
  }
  
  if (data.c.includes('.jpg') || data.c.includes('.png') || data.c.includes('.jpeg')) {
    allInputs[2].nextElementSibling.innerHTML = `<img src="${data.c}" alt="Option C" />`;
  } else {
    allInputs[2].nextElementSibling.innerText = data.c;
  }
  
  if (data.d.includes('.jpg') || data.d.includes('.png') || data.d.includes('.jpeg')) {
    allInputs[3].nextElementSibling.innerHTML = `<img src="${data.d}" alt="Option D" />`;
  } else {
    allInputs[3].nextElementSibling.innerText = data.d;
  }
  };
  
  
  const getAnswer = () => {
  let ans;
  allInputs.forEach(
    (inputEl) => {
        if (inputEl.checked) {
            ans = inputEl.value;
        }
    }
  )
  return ans;
  }
  
  const reset = () => {
  allInputs.forEach(
    (inputEl) => {
        inputEl.checked = false;
    }
  )
  }
  
  const quizEnd = () => {
  document.getElementsByClassName("container")[0].innerHTML = `
    <div class="col">
        <h2> Total correct ${correct} from ${total} </h2>
        <a align="center" href="./">Home</a>
    </div>
  `
  }
  
  loadQuestion(index);
  