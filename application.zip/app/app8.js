const quizData = [
    {
      question: "Concentration of the Ag⁺ ions in a saturated solution of Ag₂C₂O₄ is 2.24 × 10⁻⁴ mol L⁻¹. Solubility product of Ag₂C₂O₄ is (NEET – 2017)",
      a: "2.42 × 10⁻⁸ mol³L⁻³",
      b: "2.66 × 10⁻¹² mol³L⁻³",
      c: "4.5 × 10⁻¹¹ mol³L⁻³",
      d: "5.619 × 10⁻¹² mol³L⁻³",
      correct: "",
    },
    {
      question: "Following solutions were prepared by mixing different volumes of NaOH and HCl of different concentrations. (NEET – 2018)\nI. 60 mL 0.1M HCl + 40mL 0.1M NaOH\nII. 55 mL 0.1M HCl + 45 mL 0.1M NaOH\nIII. 75 mL 0.1M HCl + 100 mL 0.05M NaOH\nIV. 100 mL 0.1M HCl + 25mL 0.1M NaOH\npH of which one of them will be equal to 1?",
      a: "IV",
      b: "I",
      c: "II",
      d: "III",
      correct: "",
    },
    {
      question: "The solubility of BaSO₄ in water is 2.42 × 10⁻³ gL⁻¹ at 298K. The value of its solubility product (Kₛₚ) will be (NEET -2018). (Given molar mass of BaSO₄ = 233 g mol⁻¹)",
      a: "1.08 × 10⁻¹⁴ mol² L⁻²",
      b: "1.08 × 10⁻¹² mol² L⁻²",
      c: "1.08 × 10⁻¹⁰ mol² L⁻²",
      d: "1.08 × 10⁻⁸ mol² L⁻²",
      correct: "",
    },
    {
      question: "pH of a saturated solution of Ca(OH)₂ is 9. The Solubility product (Kₛₚ) of Ca(OH)₂ is",
      a: "0.5 × 10⁻¹⁵",
      b: "0.25 × 10⁻¹⁵",
      c: "0.125 × 10⁻¹⁰",
      d: "0.5 × 10⁻¹⁰",
      correct: "",
    },
    {
      question: "Conjugate base for Bronsted acids H₂O and HF are",
      a: "OH⁻ and H₂F⁺, respectively",
      b: "H₃O⁺ and F⁻, respectively",
      c: "OH⁻ and F⁻, respectively",
      d: "H₃O⁺ and H₂F⁺, respectively",
      correct: "",
    },
    {
      question: "Which will make basic buffer?",
      a: "50 mL of 0.1M NaOH + 25mL of 0.1M CH₃COOH",
      b: "100 mL of 0.1M CH₃COOH + 100 mL of 0.1M NH₄OH",
      c: "100 mL of 0.1M HCl + 200 mL of 0.1M NH₄OH",
      d: "100 mL of 0.1M HCl + 100 mL of 0.1M NaOH",
      correct: "",
    },
    {
      question: "Which of the following fluoro compounds is most likely to behave as a Lewis base? (NEET – 2016)",
      a: "BF₃",
      b: "PF₃",
      c: "CF₄",
      d: "SiF₄",
      correct: "",
    },
    {
      question: "Which of these is not likely to act as a Lewis base?",
      a: "BF₃",
      b: "PF₃",
      c: "CO",
      d: "F⁻",
      correct: "",
    },
    {
      question: "The aqueous solutions of sodium formate, anilinium chloride, and potassium cyanide are respectively",
      a: "acidic, acidic, basic",
      b: "basic, acidic, basic",
      c: "basic, neutral, basic",
      d: "none of these",
      correct: "",
    },
    {
      question: "The percentage of pyridine (C₅H₅N) that forms pyridinium ion (C₅H₅NH⁺) in a 0.10M aqueous pyridine solution (K_b for C₅H₅N = 1.7 × 10⁻⁹) is",
      a: "0.006%",
      b: "0.013%",
      c: "0.77%",
      d: "1.6%",
      correct: "",
    },
    {
      question: "Equal volumes of three acid solutions of pH 1, 2, and 3 are mixed in a vessel. What will be the H⁺ ion concentration in the mixture?",
      a: "3.7 × 10⁻²",
      b: "10⁻⁶",
      c: "0.111",
      d: "none of these",
      correct: "",
    },
    {
      question: "The solubility of AgCl (s) with solubility product 1.6 × 10⁻¹⁰ in 0.1M NaCl solution would be",
      a: "1.26 × 10⁻⁵M",
      b: "1.6 × 10⁻⁹ M",
      c: "1.6 × 10⁻¹¹M",
      d: "Zero",
      correct: "",
    },
    {
      question: "If the solubility product of lead iodide is 3.2 × 10⁻⁸, its solubility will be",
      a: "2 × 10⁻³M",
      b: "4 × 10⁻⁴ M",
      c: "1.6 × 10⁻⁵M",
      d: "1.8 × 10⁻⁵M",
      correct: "",
    },
    {
      question: "MY and NY₃ are insoluble salts and have the same Kₛₚ values of 6.2 × 10⁻¹³ at room temperature. Which statement would be true with regard to MY and NY₃?",
      a: "The salts MY and NY₃ are more soluble in 0.5M KY than in pure water",
      b: "The addition of the salt of KY to the suspension of MY and NY₃ will have no effect on their solubility",
      c: "The molar solubilities of MY and NY₃ in water are identical",
      d: "The molar solubility of MY in water is less than that of NY₃",
      correct: "",
    },
    {
      question: "What is the pH of the resulting solution when equal volumes of 0.1M NaOH and 0.01M HCl are mixed?",
      a: "2.0",
      b: "3",
      c: "7.0",
      d: "12.65",
      correct: "",
    },
    {
      question: "The dissociation constant of a weak acid is 1 × 10⁻³. In order to prepare a buffer solution with a pH = 4, the [Acid]/[Salt] ratio should be",
      a: "4:3",
      b: "3:4",
      c: "10:1",
      d: "1:10",
      correct: "",
    },
    {
      question: "The pH of 10⁻⁵M KOH solution will be",
      a: "9",
      b: "5",
      c: "19",
      d: "none of these",
      correct: "",
    },
    {
      question: "H₂PO₄⁻ is the conjugate base of",
      a: "PO₄³⁻",
      b: "P₂O₅",
      c: "H₃PO₄",
      d: "HPO₄²⁻",
      correct: "",
    },
    {
      question: "Which of the following can act as a Lowry–Bronsted acid as well as a base?",
      a: "HCl",
      b: "SO₄²⁻",
      c: "HPO₄²⁻",
      d: "Br⁻",
      correct: "",
    },
    {
      question: "The pH of an aqueous solution is zero. The solution is",
      a: "slightly acidic",
      b: "strongly acidic",
      c: "neutral",
      d: "basic",
      correct: "",
    },
    {
      question: "The hydrogen ion concentration of a buffer solution consisting of a weak acid and its salt is given by",
      a: "[H⁺] = Kₐ [acid]/[salt]",
      b: "[H⁺] = Kₐ [salt]",
      c: "[H⁺] = Kₐ [acid]",
      d: "[H⁺] = Kₐ [salt]/[acid]",
      correct: "",
    },
    {
      question: "Which of the following relations is correct for the degree of hydrolysis of ammonium acetate?",
      a: "h = Kₕ / C",
      b: "h = Kₐ / K_b",
      c: "h = K_w / (Kₐ . K_b)",
      d: "h = (Kₐ . K_b) / K_w",
      correct: "",
    },
    {
      question: "Dissociation constant of NH₄OH is 1.8 × 10⁻⁵. The hydrolysis constant of NH₄Cl would be",
      a: "1.8 × 10⁻¹⁹",
      b: "5.55 × 10⁻¹⁰",
      c: "5.55 × 10⁻⁵",
      d: "1.80 × 10⁻⁵",
      correct: "",
    },
  ];
  
  let index = 0;
  let correct = 0,
      incorrect = 0,
      total = quizData.length;
  let questionBox = document.getElementById("questionBox");
  let allInputs = document.querySelectorAll("input[type='radio']");
  
  const submitButton = document.querySelector("#submit");
  submitButton.disabled = true; // Initially disable the submit button
  
  // Add event listener to each input to enable/disable submit button
  allInputs.forEach(input => {
    input.addEventListener('change', () => {
      submitButton.disabled = !document.querySelector('input[type="radio"]:checked'); // Enable submit button if any radio button is checked
    });
  });
  
  // Add event listener to submit button
  submitButton.addEventListener('click', () => {
    const ans = getAnswer();
    if (ans) {
      const data = quizData[index];
      if (ans === data.correct) {
        correct++;
      } else {
        incorrect++;
      }
      index++;
      if (index < total) {
        loadQuestion();
      } else {
        quizEnd();
      }
      submitButton.disabled = true; // Disable submit button after submission
    }
  });
  
  const loadQuestion = () => {
    if (total === index) {
      return quizEnd();
    }
    reset();
    const data = quizData[index];
    questionBox.innerHTML = `${index + 1}) ${data.question}`;
    allInputs[0].nextElementSibling.innerText = data.a;
    allInputs[1].nextElementSibling.innerText = data.b;
    allInputs[2].nextElementSibling.innerText = data.c;
    allInputs[3].nextElementSibling.innerText = data.d;
  };
  
  const getAnswer = () => {
    let ans;
    allInputs.forEach(
      (inputEl) => {
        if (inputEl.checked) {
          ans = inputEl.value;
        }
      }
    )
    return ans;
  }
  
  const reset = () => {
    allInputs.forEach(
      (inputEl) => {
        inputEl.checked = false;
      }
    )
  }
  
  const quizEnd = () => {
    document.getElementsByClassName("container")[0].innerHTML = `
      <div class="col">
          <h2> Total correct ${correct} from ${total} </h2>
          <a align="center" href="./">Home</a>
      </div>
    `
  }
  
  loadQuestion(index);
  